package parcialDPPO_app;

import parcialDPPO_Logica.Pieza;

public class app {
	public Pieza PiezaActual;
	public app(Pieza p) {
		this.PiezaActual = p;
	}
	public int getNumMov(Pieza PiezaActual) {
		return PiezaActual.getListaNum();
	}
	
}
