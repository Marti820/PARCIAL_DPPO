package parcialDPPO_Logica;

import java.util.ArrayList;
import parcialDPPO_Logica.Pieza;
public class Peon extends Pieza {
    
	
	public Peon(PosicionEnTablero PosActualDada) {
		super(PosActualDada);
		// TODO Auto-generated constructor stub
	}

	@Override
	public ArrayList<PosicionEnTablero> getListaMovimientos() {
		// TODO Auto-generated method stub
		ArrayList<PosicionEnTablero> rta = new ArrayList<PosicionEnTablero>();
		if (PosActual.getPosicionY() == 2) {
			for(int i = 1; i <= 8 ; i = i + 1)
			{

			}
		}
		else {
			for(int i = 1; i <= 8 ; i = i + 1)
			{
				PosicionEnTablero pos = new PosicionEnTablero(i,PosActual.getPosicionX());
				rta.add(pos);
			}
		}
		return rta;
	}

	@Override
	public int getListaNum() {
		// TODO Auto-generated method stub
		return getListaMovimientos().size();
	}

}