package parcialDPPO_Logica;

import java.util.ArrayList;

public class Torre extends Pieza {

	public Torre(PosicionEnTablero PosActualDada) {
		super(PosActualDada);
		// TODO Auto-generated constructor stub
	}

	@Override
	public ArrayList<PosicionEnTablero> getListaMovimientos() {
		// TODO Auto-generated method stub
		ArrayList<PosicionEnTablero> rta = new ArrayList<PosicionEnTablero>();
			for(int i = 1; i <= 8 ; i = i + 1)
			{
				PosicionEnTablero pos1 = new PosicionEnTablero(i,2);
				PosicionEnTablero pos2 = new PosicionEnTablero(i,3);
				rta.add(pos1);
				rta.add(pos2);
			}
		return rta;
	}

	@Override
	public int getListaNum() {
		// TODO Auto-generated method stub
		return getListaMovimientos().size();
	}

}
