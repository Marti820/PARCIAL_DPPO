package parcialDPPO_Logica;

public class PosicionEnTablero {
	private int X;
	private int Y;
	
	public PosicionEnTablero(int givenX, int givenY) {
		this.X = givenX;
		this.Y = givenY;
	}
	
	public int getPosicionX() {
		return this.X;
	}
	public int getPosicionY() {
		return this.Y;
	}
}
