package parcialDPPO_Logica;

import java.util.ArrayList;
public abstract class Pieza {
	public PosicionEnTablero PosActual;
	
	public Pieza(PosicionEnTablero PosActualDada) {
		this.PosActual = PosActualDada;
	}
	
	public abstract ArrayList<PosicionEnTablero> getListaMovimientos();
	public PosicionEnTablero getPosActual() {
		return PosActual;
	}	
	public abstract int getListaNum();
}
